#' Calculate Column Means
#'
#' This function takes a data frame as input and returns a named vector of column means.
#'
#' @param df A data frame for which column means should be calculated.
#' @return A named vector of column means.
#' @examples
#' data(iris)
#' col_means(iris[1:4]) # Excluding the Species column as it's a factor
col_means <- function(df) {
  means <- numeric(ncol(df))
  names(means) <- names(df)

  for (i in seq_along(df)) {
    if (is.numeric(df[[i]])) {
      means[i] <- mean(df[[i]], na.rm = TRUE)
    } else {
      means[i] <- NA
    }
  }

  return(means)
}

#' Count NA Values in a Vector
#'
#' This function takes a vector as input and returns the number of NA values it contains.
#'
#' @param x A vector in which to count NA values.
#' @return The number of NA values in the vector.
#' @examples
#' count_na(c(1, NA, 3, NA, 5))
count_na <- function(x) {
  na_count <- 0

  for (i in seq_along(x)) {
    if (is.na(x[i])) {
      na_count <- na_count + 1
    }
  }

  return(na_count)
}

